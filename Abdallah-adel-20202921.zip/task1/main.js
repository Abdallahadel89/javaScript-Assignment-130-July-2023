function checkEven (){
    let num =  Number(prompt("enter number"))
    if (num % 2 ==0){
        console.log(`the number ${num} Is even`)
    }
    else{
        console.log(`the number ${num} is odd `)
    }
    
}

function Fizzbuzz(){
    let num = Number(prompt("enter a number "))
    if (num % 3 ==0 && num %5 == 0){
        console.log("Fizz Buzz")
        window.alert("Fizz Buzz")
    }
    else if (num %3 == 0){
        console.log("Fizz")
        window.alert("Fizz")
    }
    else if (num %5 == 0){
        console.log("Buzz")
        window.alert("Buzz")
    }
    else{
        console.log(num+1)
        window.alert(num+1)
        
    }
}
function ReverseString () {
   let s1 = prompt("Enter a String")
   let s2 =" "
   let sArray = [s1.length-1]
   for (let i= s1.length; i>=0 ;i--){
    s2+= s1.charAt(i)

   }
   console.log(s2)
   window.alert(s2)
}
function CircleAreaCircumference(){
    const pi = 3.14
    let r = prompt("enter the radius ")
    let Area = pi * Math.pow(r,2)
    let Circumference = 2 * pi * r
    console.log(`Area = ${Area} `)
    console.log(`Circumference = ${Circumference} `)
    window.alert(`the Area is ${Area} And the Circumference is ${Circumference} `)


}
function Check50 (){
    let num1 = Number(prompt("enter First number")) 
    let num2 = Number(prompt("Enter second number"))
    if (num1 == 50 || num2 ==50||num1 +num2 ==50){
        console.log(true)
        return true
    }
    else {
        console.log(false)
        return false
    }
}
function PostiveNigtive (){
    let num1 = Number(prompt("enter number1"))
    let num2 =  Number(prompt("enter number2"))
    if (num1 >0 && num2 <0){
        console.log("num 1 postive num2 neigtive")
    }
    else if (num1 <0 && num2 >0){
        console.log("num 2 postive num 1 neigtive")
    }
    else{
        console.log("both is postive or nigtive")
    }
}
function multiple(){
    let num = Number (prompt("enter a number"))
    if (num >0){
    if (num %5 ==0 ){
        console.log(`the number ${num} is a multiple of 5`)
    }else if (num %8 ==0){
        console.log(`the number ${num} is a multiple of 8`)
    }else{
        console.log(`the number ${num} is not multiple of 5 or 8`)
    }
}
else{
    console.log(`the number ${num} is not postive`)
}
}
function maxOFthree (){
    let num1 = Number (prompt("Enter first number"))
    let num2 = Number (prompt("Enter second number"))
    let num3 = Number (prompt("Enter thierd number"))
    console.log(`The max number is ${Math.max(num1,num2,num3)}`)
}
function sum1to10 (){
    let sum1 =0
    for (let i = 1; i<=10; i++){
        sum1 += i; 
    }
    console.log(sum1)
}
function triangel (){
    let t = "*"
    let len =Number (prompt("enter the length of the triangel"))
    
    for (let i =0 ;i<len;i++){
        console.log(t)
        t +=" *"
    }
}
function Checkpostive (){
    let num = Number (prompt("enter a number "))
    if (num > 0 ){
        console.log("postive")
    }
    else if (num <0) {
        console.log("negtive")
    }
    else {
        console.log("ZERO OR Not a number")
    }
}
function arr(){
    let numbers = []
    for (let i =1 ;i<11 ;i++){
        numbers.push(i);
    }
    for (let i =0 ;i<10 ;i++){
        console.log(`element ${i} - ${numbers[i]}`)
}
}
function sum(){
    let num1 = Number (prompt("Enter the first number"))
    let num2 = Number (prompt("Enter the second number"))
    console.log(`the sum is ${num1 + num2}`)

}
function factorial(){
    let num = Number (prompt("Enter the  number"))
    let fact = 1;
    for (let i = num ;i>0; i--){
        fact *= i;
    }
    console.log(fact);

}

function Calculator() {
    let num1 = Number (prompt("enter the first number"))
    let OP = prompt ("enter the operator")
    let num2 = Number (prompt("enter the second number"))
    let result ;
    if (OP === "+"){
        result = num1 + num2
    }else if (OP === "-"){
        result = num1 - num2
    }
    else if (OP === "*"){
        result = num1 * mun2 
    }
    else {
        result = num1 / mun2 
    }
    console.log(result)



    
}


